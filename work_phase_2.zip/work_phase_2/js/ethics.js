import { setupMenu } from './modules/menu.js';
document.addEventListener("DOMContentLoaded", () => {
    setupMenu();
});